(function (window) {
    window.__env = window.__env || {};
  
    // API url
    window.__env.production= false;
    window.__env.apiUrl='/api/backend/';
  }(this));